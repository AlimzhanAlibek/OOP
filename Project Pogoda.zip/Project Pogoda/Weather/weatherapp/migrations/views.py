from django.shortcuts import render
from .models import Weather

def weather_view(request):
    # Пример: получение данных из базы данных (если они есть)
    weather_data = Weather.objects.all()  # Получаем все данные о погоде

    return render(request, 'weather/index.html', {'weather_data': weather_data})

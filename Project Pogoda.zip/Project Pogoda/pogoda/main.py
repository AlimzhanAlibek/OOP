import requests
from fastapi import FastAPI

app = FastAPI()

API_KEY = '88344296624c4734a40103525251510'  # Замените на ваш ключ
BASE_URL = 'https://api.openweathermap.org/data/2.5/weather'


@app.get("/weather/{city}")
def get_weather(city: str):
    # Формируем URL для запроса
    url = f"{BASE_URL}?q={city}&appid={API_KEY}&units=metric"

    # Отправляем GET запрос к API
    response = requests.get(url)

    # Если запрос успешен (статус 200)
    if response.status_code == 200:
        data = response.json()
        return {
            "city": data["name"],
            "temperature": data["main"]["temp"],
            "description": data["weather"][0]["description"]
        }
    else:
        return {"error": "City not found or API error"}
